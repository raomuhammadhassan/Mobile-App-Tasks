import 'package:flutter/material.dart';

// section 01
void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blueAccent,
        appBar: AppBar(
          title: Text('Class Task 04 (BSSE-F22-061)'),
          backgroundColor: Colors.tealAccent,
        ),
        body: SafeArea(
        // child: Container(
        //   height: 100.0,
        //   width: 100.0,
        //   // margin: EdgeInsets.symmetric(vertical: 50.0, horizontal: 10.0),
        //   // margin: EdgeInsets.fromLTRB(30.0,20.0,40.0,10.0),
        //   margin: EdgeInsets.only(left: 20.0),
        //   padding: EdgeInsets.all(10.0),
        //   color: Colors.amber,
        //   child: Text("Hello World"),
        // )

          child: Column(

            children: [
              margin:  EdgeInsets.only(left: 70.0),
              Container(
                height: 100.0,
                width: 100.0,
                child: Text('Container 01'),
              ),
              Container(
                height: 100.0,
                width: 100.0,
                child: Text('Container 02'),
              ),
              Container(
                height: 100.0,
                width: 100.0,
                child: Text('Container 03'),
              ),
            ],
          ),
        ),
      ),
    ),
  );
}
